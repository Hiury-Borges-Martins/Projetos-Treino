
import br.com.gemeos.escolacomtdd.util.CrudAluno;
import java.io.IOException;
import java.text.ParseException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Pessoal
 */
public class TesteMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ParseException, Exception {
        
        CrudAluno cruda = new CrudAluno();
        TesteTDD tdd = new TesteTDD();
        while (true) {
           
        cruda.alunoEmExecucao();
        }

  
    }
    
}
