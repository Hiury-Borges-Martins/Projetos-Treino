/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworldswing;

/**
 *
 * @author Pessoal
 */
public class BalanssoTrimestral {

    public static void main(String[] args) {
        //        int janeiro = 15000;
        //        int fevereiro = 23000;
        //        int marco = 17000;
        //        
        //        int gastosTrimestral = janeiro + fevereiro + marco;
        //        double mediaMensal = gastosTrimestral/3;
        //        
        //        System.out.println(gastosTrimestral);
        //        System.out.println("Valor da media mensal = " + mediaMensal);
        //        
        //        int i =5;
        //        int x = i++;
        //        System.out.println(x);
        //        System.out.println(x);
        //        
        //        int y = ++i;
        //         System.out.println(y);

//        int mutiblicador = 3;
//        int resultado = 3;
//       
//        for(int i = 2; resultado < 100; i++){
//            
//            System.out.println(resultado);
//            resultado = mutiblicador * i;
//          
//        }
//        int x = 0;
//        int y = 1;
//      
//
//        while ( y < 100) {
//
//            
//            y = x + y;
//            x = y - x; 
//          
//            System.out.println("->" + y);
//        }
//        int x = 42;
//
//        while (x > 1) {
//            if (x % 2 != 0) {
//                x = 3 * x + 1;
//            } else {
//                x = x / 2;
//            }
//            System.out.print( " -> " + x );
//        }
//        for(int i = 1; i <= 10; i++){
//            
//            for(int y = 1; y <= i; y++){
//                
//                System.out.print( y * i + ", " );
//            }
//                System.out.println();
//        }
//        minhaConta = new Conta();
//
//        minhaConta.titula = "Duke";
//        minhaConta.saldo = 0;
//        minhaConta.limite = 100;
//
//        System.out.println(minhaConta.saldo);
//      if(minhaConta.saca(-1)){
//          System.out.println("Consegui sacar");
//      }else{
//          System.out.println("Não Consegui sacar");
//      }
//        System.out.println(minhaConta.saldo);
//
//        minhaConta.debosita(500);
//        System.out.println(minhaConta.saldo);
//        Conta c1;
//        c1 = new Conta();
//        c1.titula = "Duke";
//        c1.debosita(100);
//
//        Conta c2 = new Conta();
//        c2.titula = "Duke";
//        c2.debosita(100);
////        System.out.println("c1 = " + c1);
////        System.out.println("c2 = " + c2);
////
////        if (c1.titula == c2.titula) {
////            System.out.println("Contas Iguais");
////        }
//
//        c1.transferencia(c2, 50);
//        System.out.println(c1.saldo);
//        System.out.println(c2.saldo);
//        Cliente c = new Cliente();
//        Conta minhaConta = new Conta();
//        minhaConta.titula = c;
//        Cliente clienteMinhaConta = minhaConta.titula;
//        clienteMinhaConta.nome = "Judas";
//        
//        System.out.println(clienteMinhaConta.nome);
//        System.out.println(minhaConta.titula.nome);
//===============================+++++++++++=======================
////Exercicios da Questão 1 pag.61 ao 4. Pag.63. Feito por Hiury
//        ContaExecircio contaExecircio = new ContaExecircio();
//
//        contaExecircio.agencia = "12345-6";
//        contaExecircio.titula = "testeCliente";
//        contaExecircio.numero = 1;
//        contaExecircio.saldo = 1000;
//        contaExecircio.dataDeAbertura = "20/03/2020";
//
//        System.out.println("Titular: " + contaExecircio.titula);
//        System.out.println("N° Agencia: " + contaExecircio.agencia);
//        System.out.println("N° da Conta: " + contaExecircio.numero);
//        System.out.println("Data de Abertura: " + contaExecircio.dataDeAbertura);
//       
//        contaExecircio.sacar(20);
//        System.out.println("Saldo disponivel: " + contaExecircio.saldo);
//
//        contaExecircio.depositar(200);
//        System.out.println("Saldo disponivel: " + contaExecircio.saldo);
//        System.out.println("Rendimento mensal: " + contaExecircio.calculaRendimento());
//        
//        System.out.println("------------------------------------------");
//        System.out.println(contaExecircio.recuperarDadosParaImpressao());
//        ContaExecircio ce1 = new ContaExecircio();
//        ce1.agencia = "12345-6";
//        ce1.titula = "testeCliente";
//        ce1.numero = 1;
//        ce1.saldo = 1000;
//        ce1.dataDeAbertura = "20/03/2020";
//        
//        ContaExecircio ce2 = new ContaExecircio();
//        ce1.agencia = "12345-6";
//        ce1.titula = "testeCliente";
//        ce1.numero = 1;
//        ce1.saldo = 1000;
//        ce1.dataDeAbertura = "20/03/2020";
//        
//        if(ce1 == ce2){
//            System.out.println("iguais");
//        }else{
//            System.out.println("diferentes");
//        }
//        
//        
//===============================++++Higor+++++=======================
        ExecicioOO c1 = new ExecicioOO();
        ExecicioOO c2 = new ExecicioOO();

        c1.titular = "Hugo";
        c1.numero = 123;
        c1.agencia = "45678-9";
        c1.saldo = 50.0;
        c1.dataAbertura = "04/06/2015";

        c1.deposito(100.0);
        System.out.println("saldo atual: " + c1.saldo);
        System.out.println("rendimento mensal: " + c1.calcularRendimento());
        c1.saca(20.0);
        System.out.println("salvo atual: " + c1.saldo);

        System.out.println(c1.recuperaDadosParaImpressao());

        c2.titular = "Hugo";
        c2.numero = 123;
        c2.agencia = "45678-9";
        c2.saldo = 50.0;
        c2.dataAbertura = "04/06/2015";

        if(c1 == c2){
            System.out.println("igual");
        }else{
            System.out.println("diferentes");
    }
    }
}
