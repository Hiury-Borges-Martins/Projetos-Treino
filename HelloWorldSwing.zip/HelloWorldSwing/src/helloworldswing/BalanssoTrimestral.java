/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helloworldswing;

/**
 *
 * @author Pessoal
 */
public class BalanssoTrimestral {

    public static void main(String[] args) {
        //        int janeiro = 15000;
        //        int fevereiro = 23000;
        //        int marco = 17000;
        //        
        //        int gastosTrimestral = janeiro + fevereiro + marco;
        //        double mediaMensal = gastosTrimestral/3;
        //        
        //        System.out.println(gastosTrimestral);
        //        System.out.println("Valor da media mensal = " + mediaMensal);
        //        
        //        int i =5;
        //        int x = i++;
        //        System.out.println(x);
        //        System.out.println(x);
        //        
        //        int y = ++i;
        //         System.out.println(y);

//        int mutiblicador = 3;
//        int resultado = 3;
//       
//        for(int i = 2; resultado < 100; i++){
//            
//            System.out.println(resultado);
//            resultado = mutiblicador * i;
//          
//        }
        int x = 0;
        int y = 1;
      

        while ( y < 100) {

            
            y = x + y;
            x = y - x; 
          
            System.out.println("->" + y);
        }
//        int x = 42;
//
//        while (x > 1) {
//            if (x % 2 != 0) {
//                x = 3 * x + 1;
//            } else {
//                x = x / 2;
//            }
//            System.out.print( " -> " + x );
//        }
        
        
//        for(int i = 1; i <= 10; i++){
//            
//            for(int y = 1; y <= i; y++){
//                
//                System.out.print( y * i + ", " );
//            }
//                System.out.println();
//        }
    }
}
